package psu.se411.coursemanagement;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import psu.se411.coursemanagement.controllers.CourseController;
import psu.se411.coursemanagement.database.DatabaseConnection;

public class CourseManagement extends Application {

    private CourseController courseController;

    public static void main(String[] args) {
        DatabaseConnection.initializeDatabase(); // Initialize DB
        launch(args); // Launch JavaFX
    }

    @Override
    public void start(Stage primaryStage) {
        courseController = new CourseController();
        BorderPane root = new BorderPane();
        root.setTop(createMenuBar());
        root.setCenter(courseController.getView());

        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Course Management - SE411");
        primaryStage.show();
    }

    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("File");
        MenuItem aboutItem = new MenuItem("About");
        aboutItem.setOnAction(e -> showAboutDialog());
        fileMenu.getItems().add(aboutItem);
        menuBar.getMenus().add(fileMenu);
        return menuBar;
    }

    private void showAboutDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Team Members - SE411 (Spring 2024–25)");
        alert.setContentText(
            "Malik Almaghlouth - 220110056\n" +
            "Mohammad Alsultan - 220211275\n" +
            "Mohammed Alsafadi - 218110698"
        );
        alert.showAndWait();
    }
}