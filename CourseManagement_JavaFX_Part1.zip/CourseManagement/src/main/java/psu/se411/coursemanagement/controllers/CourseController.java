package psu.se411.coursemanagement.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import psu.se411.coursemanagement.models.Course;
import psu.se411.coursemanagement.services.CourseService;

public class CourseController {

    private final CourseService courseService = new CourseService();
    private final ObservableList<Course> courseList = FXCollections.observableArrayList();
    private final TableView<Course> courseTable = new TableView<>();

    private TextField idField = new TextField();
    private TextField nameField = new TextField();
    private TextField instructorField = new TextField();
    private TextField creditsField = new TextField();
    private TextField scheduleField = new TextField();

    public VBox getView() {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));

        setupTable();
        loadCourses();

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        form.add(new Label("ID:"), 0, 0);
        form.add(idField, 1, 0);
        form.add(new Label("Name:"), 0, 1);
        form.add(nameField, 1, 1);
        form.add(new Label("Instructor:"), 0, 2);
        form.add(instructorField, 1, 2);
        form.add(new Label("Credits:"), 0, 3);
        form.add(creditsField, 1, 3);
        form.add(new Label("Schedule:"), 0, 4);
        form.add(scheduleField, 1, 4);

        Button addButton = new Button("Add");
        Button removeButton = new Button("Remove");
        addButton.setOnAction(e -> addCourse());
        removeButton.setOnAction(e -> removeCourse());

        form.add(addButton, 0, 5);
        form.add(removeButton, 1, 5);

        vbox.getChildren().addAll(courseTable, form);
        return vbox;
    }

    private void setupTable() {
        TableColumn<Course, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(c -> c.getValue().idProperty());

        TableColumn<Course, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> c.getValue().nameProperty());

        TableColumn<Course, String> instructorCol = new TableColumn<>("Instructor");
        instructorCol.setCellValueFactory(c -> c.getValue().instructorProperty());

        TableColumn<Course, Number> creditsCol = new TableColumn<>("Credits");
        creditsCol.setCellValueFactory(c -> c.getValue().creditsProperty());

        TableColumn<Course, String> scheduleCol = new TableColumn<>("Schedule");
        scheduleCol.setCellValueFactory(c -> c.getValue().scheduleProperty());

        courseTable.getColumns().addAll(idCol, nameCol, instructorCol, creditsCol, scheduleCol);
        courseTable.setItems(courseList);
    }

    private void loadCourses() {
        courseList.setAll(courseService.getCourses());
    }

    private void addCourse() {
        Course course = new Course(
            idField.getText(),
            nameField.getText(),
            instructorField.getText(),
            Double.parseDouble(creditsField.getText()),
            scheduleField.getText()
        );
        courseService.addCourse(course);
        courseList.add(course);
        clearFields();
    }

    private void removeCourse() {
        Course selected = courseTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            courseService.removeCourse(selected.getId());
            courseList.remove(selected);
        }
    }

    private void clearFields() {
        idField.clear();
        nameField.clear();
        instructorField.clear();
        creditsField.clear();
        scheduleField.clear();
    }
}