package psu.se411.coursemanagement.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:h2:./course_management_db";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public static Connection connect() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void initializeDatabase() {
        String sql = "CREATE TABLE IF NOT EXISTS courses (" +
                     "id VARCHAR(10) PRIMARY KEY," +
                     "name VARCHAR(100)," +
                     "instructor VARCHAR(100)," +
                     "credits DOUBLE," +
                     "schedule VARCHAR(50)" +
                     ");";
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}