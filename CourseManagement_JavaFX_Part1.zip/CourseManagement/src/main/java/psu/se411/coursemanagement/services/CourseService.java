package psu.se411.coursemanagement.services;

import psu.se411.coursemanagement.database.DatabaseConnection;
import psu.se411.coursemanagement.models.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseService {

    public void addCourse(Course course) {
        String sql = "MERGE INTO courses (id, name, instructor, credits, schedule) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, course.getId());
            stmt.setString(2, course.getName());
            stmt.setString(3, course.getInstructor());
            stmt.setDouble(4, course.getCredits());
            stmt.setString(5, course.getSchedule());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeCourse(String id) {
        String sql = "DELETE FROM courses WHERE id=?";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Course> getCourses() {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT * FROM courses";
        try (Connection conn = DatabaseConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Course c = new Course(
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getString("instructor"),
                        rs.getDouble("credits"),
                        rs.getString("schedule")
                );
                list.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}