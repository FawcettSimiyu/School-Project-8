package psu.se411.coursemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseManagement {

    public static void main(String[] args) {
        SpringApplication.run(CourseManagement.class, args); // Start Spring Boot application
    }
}

