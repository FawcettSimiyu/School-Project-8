package psu.se411.coursemanagement.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import psu.se411.coursemanagement.models.Course;
import psu.se411.coursemanagement.services.CourseService;

@Controller
public class CourseController {

    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
    @FXML
    private TextField instructorField;
    @FXML
    private TextField creditsField;
    @FXML
    private TextField scheduleField;
    @FXML
    private TableView<Course> courseTable;
    @FXML
    private TableColumn<Course, String> idColumn;
    @FXML
    private TableColumn<Course, String> nameColumn;
    @FXML
    private TableColumn<Course, String> instructorColumn;
    @FXML
    private TableColumn<Course, Double> creditsColumn;
    @FXML
    private TableColumn<Course, String> scheduleColumn;

    @Autowired
    private CourseService courseService;  // Autowire CourseService

    private ObservableList<Course> courseList;

    public void initialize() {
        // Initialize the course list using the CourseService
        courseList = FXCollections.observableArrayList(courseService.getCourses());

        // Set up table columns
        idColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getId()));
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        instructorColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getInstructor()));
        creditsColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getCredits()).asObject());
        scheduleColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getSchedule()));

        // Bind the course table to the observable list
        courseTable.setItems(courseList);
    }

    @FXML
    private void addCourse() {
        // Create a new course based on the input fields
        Course course = new Course(
                idField.getText(),
                nameField.getText(),
                instructorField.getText(),
                Double.parseDouble(creditsField.getText()),
                scheduleField.getText()
        );
        
        // Add course to the database through the service
        courseService.addCourse(course);
        
        // Update the observable list with the newly added course
        courseList.add(course);
        
        // Clear the input fields
        clearFields();
    }

    @FXML
    private void removeCourse() {
        // Get the selected course from the table
        Course selectedCourse = courseTable.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            // Remove the course from the database
            courseService.removeCourse(selectedCourse.getId());
            
            // Remove the course from the observable list
            courseList.remove(selectedCourse);
        }
    }

    private void clearFields() {
        idField.clear();
        nameField.clear();
        instructorField.clear();
        creditsField.clear();
        scheduleField.clear();
    }
}

