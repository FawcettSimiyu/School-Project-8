package psu.se411.coursemanagement.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:h2:./course_management_db"; // File-based
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public static Connection connect() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public static void initializeDatabase() {
        String createTableSQL = """
                CREATE TABLE IF NOT EXISTS courses (
                    id VARCHAR(10) PRIMARY KEY,
                    name VARCHAR(100),
                    instructor VARCHAR(100),
                    credits INT,
                    schedule VARCHAR(50)
                );
                """;

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createTableSQL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

