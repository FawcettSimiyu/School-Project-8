package psu.se411.coursemanagement.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {

    @Id
    private String id;
    private String name;
    private String instructor;
    private double credits;
    private String schedule;

    // Default constructor for JPA
    public Course() {}

    // Constructor for easy creation of Course objects
    public Course(String id, String name, String instructor, double credits, String schedule) {
        this.id = id;
        this.name = name;
        this.instructor = instructor;
        this.credits = credits;
        this.schedule = schedule;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public double getCredits() {
        return credits;
    }

    public void setCredits(double credits) {
        this.credits = credits;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }
}

