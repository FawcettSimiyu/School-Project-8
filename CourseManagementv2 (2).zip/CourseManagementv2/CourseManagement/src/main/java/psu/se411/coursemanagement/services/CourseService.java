package psu.se411.coursemanagement.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import psu.se411.coursemanagement.models.Course;
import psu.se411.coursemanagement.repositories.CourseRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    private final CourseRepository courseRepository;

    @Autowired
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }

    // Add or update a course
    public Course addCourse(Course course) {
        return courseRepository.save(course); // Saves a course to the database
    }

    // Remove a course by ID
    public void removeCourse(String courseId) {
        courseRepository.deleteById(courseId); // Deletes course by ID
    }

    // Get all courses
    public List<Course> getCourses() {
        return courseRepository.findAll(); // Retrieves all courses
    }

    // Get course by ID
    public Optional<Course> getCourseById(String courseId) {
        return courseRepository.findById(courseId); // Retrieves a specific course by ID
    }
}

