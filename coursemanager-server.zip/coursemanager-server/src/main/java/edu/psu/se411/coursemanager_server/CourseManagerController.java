package edu.psu.se411.coursemanager_server;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseManagerController {
    private final CourseRepository repo;
    public CourseManagerController(CourseRepository repo) { this.repo = repo; }

    @PostMapping
    public Course addCourse(@RequestBody Course c) { return repo.save(c); }

    @GetMapping("/{id}")
    public ResponseEntity<Course> getById(@PathVariable String id) {
        return repo.findById(id)
                   .map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Course> all() { return repo.findAll(); }
}