package edu.psu.se411.coursemanager_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CoursemanagerServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursemanagerServerApplication.class, args);
	}

}
